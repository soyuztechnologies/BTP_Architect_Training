const MyService = function(srv){
    //Like DPC_Ext class when we build odata in ABAP
    srv.on('helloCAP', (req,res) => {
        return "Hello CAPians, Welcome " + req.data.name;
    });
}
//http://localhost:4004/my/helloCAP(name='Anubhav')
module.exports = MyService;